#include <stdio.h>

int main =42;
int *ptr = &num;
printf("value of the num %d\n",num);
printf("value of the num %p\n",num);
      printf("value f the num using ponters : %d\n",*ptr);
      printf("adress of the num uing %p\n",ptr);
      return 0;}
